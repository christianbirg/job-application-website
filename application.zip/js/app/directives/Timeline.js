application.directive('timeline', function() {
    return {
      restrict: 'E',
      templateUrl: 'views/_partials/timeline.html'
    };
})
