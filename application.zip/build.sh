zip -r application.zip *
