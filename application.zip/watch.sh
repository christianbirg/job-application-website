compass watch
